package tugas.akhir.kelompok3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kelompok3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
